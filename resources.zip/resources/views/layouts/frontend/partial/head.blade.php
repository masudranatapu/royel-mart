<link rel="stylesheet" href="{{asset('frontend/css/plugin.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/style.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/responsive.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/translate.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('backend/assets/icon/font-awesome/css/font-awesome.min.css')}}">
<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">
