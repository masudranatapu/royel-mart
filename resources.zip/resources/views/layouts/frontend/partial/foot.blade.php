<script type="text/javascript" src="{{asset('frontend/js/plugin.js')}}"></script>
<script type="text/javascript" src="{{asset('frontend/js/script.js')}}"></script>