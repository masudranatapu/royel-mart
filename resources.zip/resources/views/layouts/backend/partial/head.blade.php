<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800" rel="stylesheet">
<!-- Required Fremwork -->
<link rel="stylesheet" type="text/css" href="{{ asset('backend/bower_components/bootstrap/dist/css/bootstrap.min.css')}}">
<!-- themify-icons line icon -->
<link rel="stylesheet" type="text/css" href="{{ asset('backend/assets/icon/themify-icons/themify-icons.css')}}">
<!-- ico font -->
<link rel="stylesheet" type="text/css" href="{{ asset('backend/assets/icon/icofont/css/icofont.css')}}">
<!-- feather Awesome -->
<link rel="stylesheet" type="text/css" href="{{ asset('backend/assets/icon/feather/css/feather.css')}}">
<!-- Font Awesome -->
<link rel="stylesheet" type="text/css" href="{{asset('backend/assets/icon/font-awesome/css/font-awesome.min.css')}}">
<!-- Data Table Css -->
<link rel="stylesheet" type="text/css" href="{{ asset('backend/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{ asset('backend/assets/pages/data-table/css/buttons.dataTables.min.css')}}">
<link rel="stylesheet" type="text/css"href="{{ asset('backend/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{ asset('backend/bower_components/jquery-minicolors/jquery.minicolors.css')}}" />
<link rel="stylesheet" href="{{ asset('backend/bower_components/select2/dist/css/select2.min.css')}}" />
<link rel="stylesheet" type="text/css" href="{{ asset('backend/bower_components/spectrum/spectrum.css')}}" />
<!-- Style.css -->
<link rel="stylesheet" type="text/css" href="{{ asset('backend/assets/css/style.css')}}">
<link rel="stylesheet" type="text/css" href="{{ asset('backend/assets/css/jquery.mCustomScrollbar.css')}}">
<link rel="stylesheet" type="text/css" href="{{ asset('backend/assets/css/jquery.mCustomScrollbar.css')}}">
