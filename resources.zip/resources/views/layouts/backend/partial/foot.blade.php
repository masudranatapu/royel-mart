<!-- Required Jquery -->
<script type="text/javascript" src="{{asset('backend/bower_components/jquery/dist/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{asset('backend/bower_components/jquery-ui/jquery-ui.min.js')}}"></script>
<script type="text/javascript" src="{{asset('backend/bower_components/popper.js/dist/umd/popper.min.js')}}"></script>
<script type="text/javascript" src="{{asset('backend/bower_components/bootstrap/dist/js/bootstrap.min.js')}}"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="{{asset('backend/bower_components/jquery-slimscroll/jquery.slimscroll.js')}}"></script>
<!-- modernizr js -->
<script type="text/javascript" src="{{asset('backend/bower_components/modernizr/modernizr.js')}}"></script>
<script type="text/javascript" src="{{asset('backend/bower_components/modernizr/feature-detects/css-scrollbars.js')}}"></script>
<!-- data-table js -->
<script src="{{asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('backend/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('backend/assets/pages/data-table/js/jszip.min.js')}}"></script>
<script src="{{asset('backend/assets/pages/data-table/js/pdfmake.min.js')}}"></script>
<script src="{{asset('backend/assets/pages/data-table/js/vfs_fonts.js')}}"></script>
<script src="{{asset('backend/bower_components/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
<script src="{{asset('backend/bower_components/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
<script src="{{asset('backend/assets/pages/data-table/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('backend/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('backend/bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>
<!-- i18next.min.js -->
<script type="text/javascript" src="{{asset('backend/bower_components/i18next/i18next.min.js')}}"></script>
<script type="text/javascript" src="{{asset('backend/bower_components/i18next-xhr-backend/i18nextXHRBackend.min.js')}}"></script>
<script type="text/javascript" src="{{asset('backend/bower_components/i18next-browser-languagedetector/i18nextBrowserLanguageDetector.min.js')}}"></script>
<script type="text/javascript" src="{{asset('backend/bower_components/jquery-i18next/jquery-i18next.min.js')}}"></script>
<!-- Select 2 js -->
<script type="text/javascript" src="{{asset('backend/bower_components/select2/dist/js/select2.full.min.js')}}"></script>
<!-- Custom js -->
<script src="{{asset('backend/assets/pages/data-table/js/data-table-custom.j')}}s"></script>
<script src="{{asset('backend/assets/js/pcoded.min.js')}}"></script>
<script src="{{asset('backend/assets/js/vartical-layout.min.js')}}"></script>
<script src="{{asset('backend/assets/js/jquery.mCustomScrollbar.concat.min.js')}}"></script>
<script type="text/javascript" src="{{asset('backend/assets/js/script.js')}}"></script>

<!-- Color picker js -->
<script type="text/javascript" src="{{asset('backend/bower_components/spectrum/spectrum.js')}}"></script>
<script type="text/javascript" src="{{asset('backend/bower_components/jscolor/jscolor.js')}}"></script>
<!-- Mini-color js -->
<script type="text/javascript" src="{{asset('backend/bower_components/jquery-minicolors/jquery.minicolors.min.js')}}"></script>

<script type="text/javascript" src="{{asset('backend/assets/pages/advance-elements/custom-picker.js')}}"></script>

<script>
    $('.js-example-basic-single').slect2();
</script>
