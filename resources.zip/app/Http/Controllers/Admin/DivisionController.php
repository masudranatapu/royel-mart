<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use App\Models\Division;
use Carbon\Carbon;

class DivisionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $title = "Division";
        $divisions = Division::latest()->get();
        return view('admin.location.indexdiv', compact('title', 'divisions'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->validate($request, [
            'name' => 'required',
        ]);
        Division::insert([
            'name' => $request->name,
            'charge' => $request->charge,
            'status' => '1',
            'created_at' => Carbon::now(),
        ]);
        Toastr::success('Division Successfully Save :-)','Success');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function divisionActive($id)
    {
        //
        Division::findOrFail($id)->update(['status' => '1']);
        Toastr::info('Division successfully inactive :-)','Success');
        return redirect()->back();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function divisionInactive($id)
    {
        //
        Division::findOrFail($id)->update(['status' => '0']);
        Toastr::info('Division successfully inactive :-)','Success');
        return redirect()->back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, [
            'name' => 'required',
        ]);
        Division::findOrFail($id)->update([
            'name' => $request->name,
            'charge' => $request->charge,
            'updated_at' => Carbon::now(),
        ]);
        Toastr::info('Division Successfully update :-)','Success');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        Division::findOrFail($id)->delete();
        Toastr::info('Division Successfully delete :-)','Success');
        return redirect()->back();
    }
}